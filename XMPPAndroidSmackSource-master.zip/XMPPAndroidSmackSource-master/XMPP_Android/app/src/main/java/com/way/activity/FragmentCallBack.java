package com.way.activity;

import com.way.service.XXService;

public interface FragmentCallBack {
	public XXService getService();

	public MainActivity getMainActivity();
}
