# XMPPAndroidSmackSource


Android client: https://github.com/whtchl/XMPPAndroidSmackSource.git
Server :https://github.com/whtchl/openfire_server.git

<img src="https://raw.githubusercontent.com/whtchl/XMPPAndroidSmackSource/master/art/patientcall1.gif"/>